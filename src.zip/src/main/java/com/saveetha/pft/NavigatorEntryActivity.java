package com.saveetha.pft;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class NavigatorEntryActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_entry);
    }
}
