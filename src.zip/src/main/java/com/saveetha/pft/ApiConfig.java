package com.saveetha.pft;

public class ApiConfig {
    // Centralized API Base URL
    public static final String BASE_URL = "http://14.139.187.229:8081/pft/";
}
