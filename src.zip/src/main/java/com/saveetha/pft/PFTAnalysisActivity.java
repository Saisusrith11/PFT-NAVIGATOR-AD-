package com.saveetha.pft;


import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;

public class PFTAnalysisActivity extends AppCompatActivity {

    EditText etRatio;
    private int patientId;
    Button btnCheck, btnGrading, btnReversibility, btnBackHome1;
    TextView tvDiagnosis, tvDiagnosis1, tvDiagnosis2;
    double storedRatio, storedFVC;

    String diagnosis = "";
    String gradingStage = "";

    String result="";
    String stage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pft_analysis);

        String patientIdStr = getIntent().getStringExtra("patient_id");

        if (patientIdStr != null || patientIdStr.isEmpty()) {
            Toast.makeText(this, "Patient ID: " + patientIdStr, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "No Patient ID received", Toast.LENGTH_SHORT).show();
        }


        etRatio = findViewById(R.id.etRatio);
        btnCheck = findViewById(R.id.btnCheck);
        tvDiagnosis = findViewById(R.id.tvDiagnosis);
        tvDiagnosis1 = findViewById(R.id.tvDiagnosis1);
        tvDiagnosis2 = findViewById(R.id.tvDiagnosis2);
        btnGrading = findViewById(R.id.btnGrading);
        btnReversibility = findViewById(R.id.btnReversibility);
        btnBackHome1 = findViewById(R.id.btnBackHome1);


        btnCheck.setOnClickListener(v -> {
            String s = etRatio.getText().toString().trim();
            if (s.isEmpty()) {
                Toast.makeText(this, "Enter FEV1/FVC ratio", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                storedRatio = Double.parseDouble(s);
                handleRatio(storedRatio);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
            }
        });

        btnGrading.setOnClickListener(v -> {
            showDoubleInputDialog("Enter FEV1 (% predicted)", val -> {

                if (val < 30) stage = "Stage 4 obstruction";
                else if (val < 50) stage = "Stage 3 obstruction";
                else if (val < 80) stage = "Stage 2 obstruction";
                else stage = "Stage 1 obstruction";
                tvDiagnosis1.setText(stage);
                tvDiagnosis1.setVisibility(View.VISIBLE);
               // showMessage("Grading Result", stage);
            });
        });

        btnReversibility.setOnClickListener(v -> showReversibilityDialog());
        btnBackHome1.setOnClickListener(v -> {
            patientId = Integer.parseInt(patientIdStr);
            savePftResult(patientId, stage, diagnosis, result);

            Intent intent = new Intent(this, EvaluatePFTFindingsDashboard.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("patient_id", patientId);
            startActivity(intent);
        });


    }

    private interface ValueCallback { void onValue(double value); }

    private void showDoubleInputDialog(String title, ValueCallback cb) {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(input)
                .setPositiveButton("OK", (dialog, which) -> {
                    try {
                        double val = Double.parseDouble(input.getText().toString().trim());
                        cb.onValue(val);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void handleRatio(double ratio) {
        if (ratio > 70) {
            showDoubleInputDialog("Enter FVC (% predicted)", fvc -> {
                storedFVC = fvc;
                if (fvc < 80) diagnosis = "Restrictive lung disease";
                else diagnosis = "Normal";
                tvDiagnosis.setText(diagnosis);
                tvDiagnosis.setVisibility(View.VISIBLE);
            });
        } else {
            showDoubleInputDialog("Enter FVC (% predicted)", fvc -> {
                storedFVC = fvc;
                if (fvc < 80) diagnosis = "Mixed";
                else diagnosis = "Pure obstruction";
                tvDiagnosis.setText(diagnosis);
                tvDiagnosis.setVisibility(View.VISIBLE);
                btnGrading.setVisibility(View.VISIBLE);
                btnReversibility.setVisibility(View.VISIBLE);
            });
        }
    }


    private void showReversibilityDialog() {
        View view = getLayoutInflater().inflate(R.layout.dialog_reversibility, null);
        final EditText etPostFEV1 = view.findViewById(R.id.etPostFEV1);
        final EditText etPostFVC  = view.findViewById(R.id.etPostFVC);
        final EditText etPreFEV1  = view.findViewById(R.id.etPreFEV1);
        final EditText etPreFVC   = view.findViewById(R.id.etPreFVC);

        new AlertDialog.Builder(this)
                .setTitle("Enter Pre & Post Values")
                .setView(view)
                .setPositiveButton("Check", (dialog, which) -> {
                    try {
                        double postFEV1 = Double.parseDouble(etPostFEV1.getText().toString().trim());
                        double postFVC  = Double.parseDouble(etPostFVC.getText().toString().trim());
                        double preFEV1  = Double.parseDouble(etPreFEV1.getText().toString().trim());
                        double preFVC   = Double.parseDouble(etPreFVC.getText().toString().trim());

                        result = computeReversibility(preFEV1, postFEV1, preFVC, postFVC);
                        tvDiagnosis2.setText(result);
                        tvDiagnosis2.setVisibility(View.VISIBLE);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Enter valid numbers", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
            }

    private String computeReversibility(double preFEV1, double postFEV1, double preFVC, double postFVC) {
        if (preFEV1 <= 0 || preFVC <= 0) return "Pre values must be > 0";
        double perFEV1 = ((postFEV1 - preFEV1) / preFEV1) * 100;
        double perFVC  = ((postFVC - preFVC) / preFVC) * 100;
        perFEV1 = Math.round(perFEV1 * 10) / 10.0;
        perFVC = Math.round(perFVC * 10) / 10.0;

        boolean reversible = perFEV1 >= 12 || perFVC >= 12;

        return "FEV1 change: " + perFEV1 + "%\n" +
                "FVC change: " + perFVC + "%\n\n" +
                (reversible ? "Reversibility present" : "No significant reversibility");
    }
    private void savePftResult(int patientId, String stage, String diagnosis, String reversibility) {

        String url = ApiConfig.BASE_URL + "save_pft_result.php";
        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    Toast.makeText(this, "Saved successfully", Toast.LENGTH_SHORT).show();
                },
                error -> {
                    Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("patient_id", String.valueOf(patientId));
                params.put("stage", stage);
                params.put("diagnosis", diagnosis);
                params.put("reversibility_result", result);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }

}
