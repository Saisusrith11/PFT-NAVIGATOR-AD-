package com.saveetha.pft;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PatientAdapter extends RecyclerView.Adapter<PatientAdapter.PatientViewHolder> {
    Context context;
    List<Patient> patientList;

    public PatientAdapter(Context context, List<Patient> patientList) {
        this.context = context;
        this.patientList = patientList;
    }

    @NonNull
    @Override
    public PatientViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_patient, parent, false);
        return new PatientViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PatientViewHolder holder, int position) {
        Patient patient = patientList.get(position);
        holder.nameText.setText(patient.full_name);
        holder.idText.setText(patient.id);
        holder.profileImage.setImageResource(patient.imageResId);

        // ✅ On click, go to PFTMainActivity instead of directly to dashboard
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, PFTMainActivity.class);
            intent.putExtra("patient_id", patient.id);  // pass patient_id to PFTMainActivity
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return patientList.size();
    }

    public static class PatientViewHolder extends RecyclerView.ViewHolder {
        TextView nameText, idText;
        ImageView profileImage;

        public PatientViewHolder(@NonNull View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.tvPatientName);
            idText = itemView.findViewById(R.id.tvPatientID);
            profileImage = itemView.findViewById(R.id.imgPatient);
        }
    }
}
