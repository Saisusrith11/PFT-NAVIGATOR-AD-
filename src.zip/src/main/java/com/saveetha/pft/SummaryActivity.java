package com.saveetha.pft;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;


public class SummaryActivity extends AppCompatActivity {

    TextView tvSummaryContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        tvSummaryContent = findViewById(R.id.tvSummaryContent);

        // Example consolidated report text (later you can pass actual user choices via Intent extras)
        String obstruction = getIntent().getStringExtra("obstruction");
        String obstructionSeverity = getIntent().getStringExtra("obstructionSeverity");
        String reversibility = getIntent().getStringExtra("reversibility");
        String restriction = getIntent().getStringExtra("restriction");
        String restrictionSeverity = getIntent().getStringExtra("restrictionSeverity");

        // Build the report
        StringBuilder report = new StringBuilder();
        report.append("PFT Interpretation:\n\n");

        if (obstruction != null) report.append("Obstruction: ").append(obstruction).append("\n");
        if (obstructionSeverity != null) report.append("Obstruction Severity: ").append(obstructionSeverity).append("\n");
        if (reversibility != null) report.append("Reversibility: ").append(reversibility).append("\n");
        if (restriction != null) report.append("Restriction: ").append(restriction).append("\n");
        if (restrictionSeverity != null) report.append("Restriction Severity: ").append(restrictionSeverity).append("\n");

        report.append("\nSummary: Please correlate with clinical findings and complete PFT report for final diagnosis.");

        tvSummaryContent.setText(report.toString());

        findViewById(R.id.btnBackHome).setOnClickListener(v -> {
            Intent intent = new Intent(this, EvaluatePFTFindingsDashboard.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
    }
}