package com.saveetha.pft;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class PFTResultsViewActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    PFTResultsAdapter adapter;  // ✅ keep global adapter reference
    String patientId;

    String API_URL = ApiConfig.BASE_URL + "get_pft_results.php?patient_id=";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pft_results_view);

        recyclerView = findViewById(R.id.recyclerViewResults);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // ✅ attach empty adapter first
        adapter = new PFTResultsAdapter(this, new ArrayList<>());
        recyclerView.setAdapter(adapter);

        patientId = getIntent().getStringExtra("patient_id");

        loadAllResults();
    }

    private void loadAllResults() {
        String url = API_URL + patientId;

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        // Log raw response
                        Log.d("API_RESPONSE", "Full Response: " + response.toString());

                        if (response.getBoolean("success")) {
                            JSONArray data = response.getJSONArray("data");
                            List<PFTResultModel> list = new ArrayList<>();
                            for (int i = 0; i < data.length(); i++) {
                                JSONObject obj = data.getJSONObject(i);
                                list.add(new PFTResultModel(
                                        obj.getString("stage"),
                                        obj.getString("diagnosis"),
                                        obj.getString("reversibility")  // now matches PHP alias
                                ));
                            }

                            PFTResultsAdapter adapter = new PFTResultsAdapter(this, list);
                            recyclerView.setAdapter(adapter);

                        } else {
                            Toast.makeText(this, "No results found", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Parsing error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    error.printStackTrace();
                    Toast.makeText(this, "Volley error: " + error.getMessage(), Toast.LENGTH_LONG).show();
                });

        Volley.newRequestQueue(this).add(request);
    }

}
