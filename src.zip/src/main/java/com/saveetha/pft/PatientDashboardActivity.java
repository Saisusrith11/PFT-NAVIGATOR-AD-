package com.saveetha.pft;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.Arrays;
import java.util.List;

public class PatientDashboardActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    List<PatientSheetItem> sheetItems;
    String patientId;
    private static final String TAG = "PatientDashboardActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_dashboard);

        patientId = getIntent().getStringExtra("patient_id");
        if (patientId == null || patientId.isEmpty()) {
            Toast.makeText(this, "Invalid patient ID", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        recyclerView = findViewById(R.id.recyclerViewSheets);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        // Lambda-based navigation
        sheetItems = Arrays.asList(
                new PatientSheetItem(
                        R.drawable.pft,
                        "Evaluate PFT Findings",
                        v -> checkPftResultAndNavigate()
                )
        );

        PatientSheetAdapter adapter = new PatientSheetAdapter(this, sheetItems);
        recyclerView.setAdapter(adapter);
    }

    private void checkPftResultAndNavigate() {
        Log.d(TAG, "Checking DB for patient_id=" + patientId);

        String url = ApiConfig.BASE_URL + "check_pft_result.php?patient_id=" + patientId;

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        Log.d(TAG, "API Response: " + response);

                        if (response.getString("status").equals("success")) {
                            // ✅ Show saved result
                            JSONObject data = response.getJSONObject("data");

                            Intent intent = new Intent(this, PFTResultsViewActivity.class);
                            intent.putExtra("patient_id", patientId);
                            intent.putExtra("stage", data.getString("stage"));
                            intent.putExtra("diagnosis", data.getString("diagnosis"));
                            intent.putExtra("reversibility", data.getString("reversibility_result"));
                            startActivity(intent);

                        } else {
                            // ❌ No result → fresh evaluation
                            Intent intent = new Intent(this, EvaluatePFTFindingsDashboard.class);
                            intent.putExtra("patient_id", patientId);
                            startActivity(intent);
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Parsing error", e);
                        Toast.makeText(this, "Parsing error", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Log.e(TAG, "Connection error", error);
                    Toast.makeText(this, "Connection error", Toast.LENGTH_SHORT).show();
                });

        Volley.newRequestQueue(this).add(request);
    }
}
