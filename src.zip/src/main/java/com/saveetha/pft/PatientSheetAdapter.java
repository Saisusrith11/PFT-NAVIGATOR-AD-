package com.saveetha.pft;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PatientSheetAdapter extends RecyclerView.Adapter<PatientSheetAdapter.ViewHolder> {

    private final List<PatientSheetItem> sheetList;
    private final Context context;

    public PatientSheetAdapter(Context context, List<PatientSheetItem> sheetList) {
        this.context = context;
        this.sheetList = sheetList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.patient_item_sheet, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PatientSheetItem item = sheetList.get(position);
        holder.icon.setImageResource(item.getIconResId());
        holder.label.setText(item.getTitle());
        holder.itemView.setOnClickListener(item.getClickListener());
    }

    @Override
    public int getItemCount() {
        return sheetList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView icon;
        TextView label;

        ViewHolder(View itemView) {
            super(itemView);
            icon = itemView.findViewById(R.id.icon);
            label = itemView.findViewById(R.id.label);
        }
    }
}
