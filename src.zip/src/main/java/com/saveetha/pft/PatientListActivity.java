
package com.saveetha.pft;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PatientListActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    FloatingActionButton fabAdd;
    private static final String TAG = "PatientListActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_list);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ViewPager2 bannerViewPager = findViewById(R.id.bannerViewPager);
        recyclerView = findViewById(R.id.recyclerViewPatients);
        fabAdd = findViewById(R.id.fabAddPatient);

        List<Integer> bannerImages = Arrays.asList(
                R.drawable.pft,
                R.drawable.iculogo3,
                R.drawable.pft
        );
        bannerViewPager.setAdapter(new BannerAdapter(bannerImages));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        fetchPatientsFromServer(); // Load dynamic data

        fabAdd.setOnClickListener(v ->
                startActivity(new Intent(PatientListActivity.this, PatientEntryActivity.class)));
    }

    private void fetchPatientsFromServer() {

        String url = ApiConfig.BASE_URL + "fetch_patients.php";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        Log.d(TAG, "Response: " + response.toString());

                        if (response.getString("status").equals("success")) {
                            JSONArray array = response.getJSONArray("data"); // 👈 from PHP response
                            List<Patient> patientList = new ArrayList<>();

                            for (int i = 0; i < array.length(); i++) {
                                JSONObject obj = array.getJSONObject(i);
                                String id = obj.getString("id");
                                String name = obj.getString("full_name");
                                int img = R.drawable.iculogo3; // dummy icon
                                patientList.add(new Patient(id, name, img));
                            }

                            PatientAdapter adapter = new PatientAdapter(this, patientList);
                            recyclerView.setAdapter(adapter);
                        } else {
                            Toast.makeText(this, "No patients found", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Parsing error: " + e.getMessage());
                        e.printStackTrace();
                        Toast.makeText(this, "Parsing error", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Log.e(TAG, "Volley error: " + error.toString());
                    error.printStackTrace();
                    Toast.makeText(this, "Connection error: " + error.toString(), Toast.LENGTH_LONG).show();
                });

        Volley.newRequestQueue(this).add(request);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            showLogoutDialog();   // ✅ show confirmation dialog
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showLogoutDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Are you sure you want to logout?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Perform logout
                        Intent intent = new Intent(PatientListActivity.this, LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                    }
                })
                .setNegativeButton("No", null)
                .show();
    }
}

