package com.saveetha.pft;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;


public class Step2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_step2);

        View.OnClickListener listener = v -> {
            Intent intent = new Intent(this, Step4Activity.class);
            intent.putExtras(getIntent()); // Keep previous choices
            String reversibility = ((Button)v).getText().toString();
            intent.putExtra("reversibility", reversibility);
            startActivity(intent);
        };

        findViewById(R.id.btnNoReversibility).setOnClickListener(listener);
        findViewById(R.id.btnYesReversibility).setOnClickListener(listener);
        findViewById(R.id.btnFvcNormalized).setOnClickListener(listener);
    }
}
