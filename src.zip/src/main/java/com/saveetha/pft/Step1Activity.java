package com.saveetha.pft;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Step1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_step1);

        findViewById(R.id.btnNoObstruction).setOnClickListener(v -> {
            Intent intent = new Intent(this, Step4Activity.class);
            intent.putExtra("obstruction", "No Obstruction");
            startActivity(intent);
        });

        findViewById(R.id.btnObstructionPresent).setOnClickListener(v -> {
            Intent intent = new Intent(this, Step1bActivity.class);
            intent.putExtra("obstruction", "Obstruction Present");
            startActivity(intent);
        });
    }
}
