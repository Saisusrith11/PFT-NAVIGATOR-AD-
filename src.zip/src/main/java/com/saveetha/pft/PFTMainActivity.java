package com.saveetha.pft;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PFTMainActivity extends AppCompatActivity {

    Button btnAddRecord, btnViewRecords;
    String patientId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pft_main);
        patientId = getIntent().getStringExtra("patient_id");
        if (patientId != null) {
            Toast.makeText(this, "Patient ID: " + patientId, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "No Patient ID received", Toast.LENGTH_SHORT).show();
        }

        btnAddRecord = findViewById(R.id.btnAddRecord);
        btnViewRecords = findViewById(R.id.btnViewRecords);

        btnAddRecord.setOnClickListener(v -> {
            Intent intent = new Intent(this, EvaluatePFTFindingsDashboard.class);
            intent.putExtra("patient_id", patientId);
            startActivity(intent);
        });

        btnViewRecords.setOnClickListener(v -> {
            Intent intent = new Intent(this, PFTResultsViewActivity.class);
            intent.putExtra("patient_id", patientId);
            startActivity(intent);
               });
    }
}
