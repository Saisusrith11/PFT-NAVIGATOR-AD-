package com.saveetha.pft;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ClinicalIndicationsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView textView = new TextView(this);
        textView.setText("Clinical Indications Screen (Placeholder)");
        textView.setTextSize(20f);
        textView.setPadding(40, 40, 40, 40);

        setContentView(textView);
    }
}
