package com.saveetha.pft;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

public class PatientEntryActivity extends AppCompatActivity {

    EditText etFullName, etDob, etAge, etWeight, etHeight, etOccupation, ePhone;
    RadioGroup rgGender, rgMaritalStatus;
    Button btnSavePatient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_entry);
        Log.d("DEBUG", "onCreate reached");

        // Bind Views
        etFullName = findViewById(R.id.etFullName);
        etDob = findViewById(R.id.etDob);
        etAge = findViewById(R.id.etAge);
        etWeight = findViewById(R.id.etWeight);
        etHeight = findViewById(R.id.etHeight);
        etOccupation = findViewById(R.id.etOccupation);
        ePhone = findViewById(R.id.ePhone);

        rgGender = findViewById(R.id.rgGender);
        rgMaritalStatus = findViewById(R.id.rgMaritalStatus);
        btnSavePatient = findViewById(R.id.btnSavePatient);

        // Button Click
        btnSavePatient.setOnClickListener(v -> {
            Log.d("DEBUG", "Save Button Clicked");

            String url = ApiConfig.BASE_URL + "save_patient.php";
            JSONObject jsonBody = new JSONObject();
            try {
                int genderId = rgGender.getCheckedRadioButtonId();
                int maritalId = rgMaritalStatus.getCheckedRadioButtonId();

                if (genderId == -1 || maritalId == -1) {
                    Toast.makeText(this, "Please select Gender and Marital Status", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Convert age safely
                int age = 0;
                try {
                    age = Integer.parseInt(etAge.getText().toString().trim());
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Enter a valid age", Toast.LENGTH_SHORT).show();
                    return;
                }

                jsonBody.put("full_name", etFullName.getText().toString().trim());
                jsonBody.put("dob", etDob.getText().toString().trim());
                jsonBody.put("age", age);
                jsonBody.put("gender", ((RadioButton) findViewById(genderId)).getText().toString());
                jsonBody.put("weight", etWeight.getText().toString().trim());
                jsonBody.put("height", etHeight.getText().toString().trim());
                jsonBody.put("occupation", etOccupation.getText().toString().trim());
                jsonBody.put("marital_status", ((RadioButton) findViewById(maritalId)).getText().toString());
                jsonBody.put("phone", ePhone.getText().toString().trim());

            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Invalid input", Toast.LENGTH_SHORT).show();
                return;
            }

            JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, jsonBody,
                    response -> {
                        Log.d("VOLLEY_RESPONSE", response.toString());
                        String status = response.optString("status");
                        String message = response.optString("message");

                        if ("success".equals(status)) {
                            Toast.makeText(this, "Saved: " + message, Toast.LENGTH_LONG).show();
                            finish(); // ✅ go back to PatientListActivity
                        } else if ("duplicate".equals(status)) {
                            Toast.makeText(this, "Duplicate: " + message, Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(this, "Error: " + message, Toast.LENGTH_LONG).show();
                        }
                    },
                    error -> {
                        // Print detailed error
                        String errorMsg = "Unknown error";
                        if (error.networkResponse != null && error.networkResponse.data != null) {
                            errorMsg = new String(error.networkResponse.data);
                        }
                        Log.e("VOLLEY_ERROR", "Volley error: " + error.toString() + " | Response: " + errorMsg);
                        Toast.makeText(this, "Error: " + errorMsg, Toast.LENGTH_LONG).show();
                    }
            );

            // Set retry policy
            request.setRetryPolicy(new DefaultRetryPolicy(
                    10000,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
            ));

            RequestQueue queue = Volley.newRequestQueue(PatientEntryActivity.this);
            queue.add(request);
        });
    }
}
