package com.saveetha.pft;
public class Patient {
    String full_name;
    String id;
    int imageResId; // fallback to profile icon

    public Patient(String id, String full_name, int imageResId) {
        this.full_name = full_name;
        this.id = id;
        this.imageResId = imageResId;
    }
   }
