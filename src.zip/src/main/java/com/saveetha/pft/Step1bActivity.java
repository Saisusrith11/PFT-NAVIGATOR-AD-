package com.saveetha.pft;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Step1bActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_step1b);

        View.OnClickListener listener = v -> {
            Intent intent = new Intent(this, Step2Activity.class);
            intent.putExtras(getIntent()); // Keep old extras
            intent.putExtra("obstructionSeverity", "Moderate");
            startActivity(intent);
        };

        findViewById(R.id.btnMild).setOnClickListener(listener);
        findViewById(R.id.btnModerate).setOnClickListener(listener);
        findViewById(R.id.btnModSevere).setOnClickListener(listener);
        findViewById(R.id.btnSevere).setOnClickListener(listener);
        findViewById(R.id.btnVerySevere).setOnClickListener(listener);
    }
}
