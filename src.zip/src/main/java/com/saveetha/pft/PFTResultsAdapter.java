package com.saveetha.pft;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class PFTResultsAdapter extends RecyclerView.Adapter<PFTResultsAdapter.ViewHolder> {

    private List<PFTResultModel> resultList;
    private final Context context;

    public PFTResultsAdapter(Context context, List<PFTResultModel> resultList) {
        this.context = context;
        this.resultList = resultList != null ? resultList : new ArrayList<>();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_pft_result, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PFTResultModel result = resultList.get(position);
        holder.tvStage.setText("Stage: " + result.getStage());
        holder.tvDiagnosis.setText("Diagnosis: " + result.getDiagnosis());
        holder.tvReversibility.setText("Reversibility: " + result.getReversibility());
    }

    @Override
    public int getItemCount() {
        return resultList.size();
    }

    // ✅ Add method to update list later
    public void updateList(List<PFTResultModel> newList) {
        this.resultList = newList != null ? newList : new ArrayList<>();
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvStage, tvDiagnosis, tvReversibility;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvStage = itemView.findViewById(R.id.tvStage);
            tvDiagnosis = itemView.findViewById(R.id.tvDiagnosis);
            tvReversibility = itemView.findViewById(R.id.tvReversibility);
        }
    }
}
