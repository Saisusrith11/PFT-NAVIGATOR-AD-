package com.saveetha.pft;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;



public class RestrictionSeverityActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restriction_severity);

        View.OnClickListener listener = v -> {
            startActivity(new Intent(this, SummaryActivity.class));
        };

        findViewById(R.id.btnMildRestriction).setOnClickListener(listener);
        findViewById(R.id.btnModerateRestriction).setOnClickListener(listener);
        findViewById(R.id.btnModSevereRestriction).setOnClickListener(listener);
        findViewById(R.id.btnSevereRestriction).setOnClickListener(listener);
        findViewById(R.id.btnVerySevereRestriction).setOnClickListener(listener);
    }
}
