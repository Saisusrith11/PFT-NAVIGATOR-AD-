package com.saveetha.pft;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class Step4Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_step4);

        findViewById(R.id.btnNoRestriction).setOnClickListener(v -> {
            Intent intent = new Intent(this, SummaryActivity.class);
            intent.putExtras(getIntent());
            intent.putExtra("restriction", "No Restriction");
            startActivity(intent);
        });

        findViewById(R.id.btnRestrictionPresent).setOnClickListener(v -> {
            Intent intent = new Intent(this, RestrictionSeverityActivity.class);
            intent.putExtras(getIntent());
            intent.putExtra("restriction", "Restriction Present");
            startActivity(intent);
        });
    }
}
