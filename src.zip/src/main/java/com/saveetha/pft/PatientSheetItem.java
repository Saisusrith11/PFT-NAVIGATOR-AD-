package com.saveetha.pft;

import android.view.View;

public class PatientSheetItem {
    private final int iconResId;
    private final String title;
    private final View.OnClickListener clickListener;

    public PatientSheetItem(int iconResId, String title, View.OnClickListener clickListener) {
        this.iconResId = iconResId;
        this.title = title;
        this.clickListener = clickListener;
    }

    public int getIconResId() { return iconResId; }
    public String getTitle() { return title; }
    public View.OnClickListener getClickListener() { return clickListener; }
}
