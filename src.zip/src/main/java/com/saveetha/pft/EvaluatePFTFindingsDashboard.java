package com.saveetha.pft;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EvaluatePFTFindingsDashboard extends AppCompatActivity {

    String patientId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Button btnEvaluate, btnValueCheck;

        // ✅ Use the correct layout for this dashboard (change to your actual layout name)
        setContentView(R.layout.activity_evaluatepftfindings);

        // ✅ Retrieve patient_id from Intent
        patientId = getIntent().getStringExtra("patient_id");

        if (patientId != null) {
            Toast.makeText(this, "Patient ID: " + patientId, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "No Patient ID received", Toast.LENGTH_SHORT).show();
        }

        // Initialize buttons
        btnEvaluate = findViewById(R.id.btnEvaluate);
        btnValueCheck = findViewById(R.id.btnValueCheck);
           // ✅ Pass patientId to each activity if needed
        btnEvaluate.setOnClickListener(v -> {
            Intent intent = new Intent(this, Step1Activity.class);
            intent.putExtra("patient_id", patientId);
            startActivity(intent);
        });

        btnValueCheck.setOnClickListener(v -> {
            Intent intent = new Intent(this, PFTAnalysisActivity.class);
            intent.putExtra("patient_id", patientId);
            startActivity(intent);
        });


    }
}
