package com.saveetha.pft;

public class PFTResultModel {
    private String stage;
    private String diagnosis;
    private String reversibility;

    public PFTResultModel(String stage, String diagnosis, String reversibility) {
        this.stage = stage;
        this.diagnosis = diagnosis;
        this.reversibility = reversibility;
    }

    public String getStage() { return stage; }
    public String getDiagnosis() { return diagnosis; }
    public String getReversibility() { return reversibility; }
}
