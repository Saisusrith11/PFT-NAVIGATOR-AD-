package com.saveetha.pft;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class LungVolumesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // You can create a simple TextView without a separate XML
        TextView textView = new TextView(this);
        textView.setText("Lung Volumes Screen (Placeholder)");
        textView.setTextSize(20f);
        textView.setPadding(40, 40, 40, 40);

        setContentView(textView);
    }
}
